Orbit Launcher: upload this zip to your GitHub repo (delete the old zip first), run Build APK, install app-debug.apk.
